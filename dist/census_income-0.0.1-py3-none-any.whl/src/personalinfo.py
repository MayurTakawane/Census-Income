def get_user(self):
    user = 'mayurtakawane'
    return user

def get_password(self):
    password = 'dogs1818'
    return password
